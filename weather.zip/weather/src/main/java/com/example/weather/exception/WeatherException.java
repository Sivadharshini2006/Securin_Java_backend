package com.example.weather.exception;

public class WeatherException extends RuntimeException {

    public WeatherException(String message) {
        super(message);
    }
}