package com.example.weather.service.impl;

import com.example.weather.dto.MonthlyStatsDTO;
import com.example.weather.entity.WeatherRecord;
import com.example.weather.exception.WeatherException;
import com.example.weather.repository.WeatherRepository;
import com.example.weather.service.WeatherService;
import com.opencsv.CSVReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.FileReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class WeatherServiceImpl implements WeatherService {

    private static final Logger log =
            LoggerFactory.getLogger(WeatherServiceImpl.class);

    private final WeatherRepository repository;

    // ✅ Manual constructor (VERY IMPORTANT)
    public WeatherServiceImpl(WeatherRepository repository) {
        this.repository = repository;
    }

    private final DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("yyyyMMdd-HH:mm");

    @Override
    public void importCsvData(String filePath) {

        log.info("Starting CSV import...");

        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {

            List<WeatherRecord> batch = new ArrayList<>();
            String[] nextLine;
            reader.readNext(); // skip header

            while ((nextLine = reader.readNext()) != null) {

                WeatherRecord record = new WeatherRecord();
                record.setTimestamp(LocalDateTime.parse(nextLine[0].trim(), formatter));
                record.setCondition(nextLine[1].trim());
                record.setHeatIndex(parseSafe(nextLine[5]));
                record.setHumidity(parseSafe(nextLine[6]));
                record.setPressure(parseSafe(nextLine[8]));
                record.setTemperature(parseSafe(nextLine[11]));

                batch.add(record);

                if (batch.size() >= 1000) {
                    repository.saveAll(batch);
                    batch.clear();
                }
            }

            if (!batch.isEmpty()) repository.saveAll(batch);

            log.info("CSV import completed successfully");

        } catch (Exception e) {
            log.error("Error during CSV import", e);
        }
    }

    @Override
    public List<WeatherRecord> getWeatherData(Integer year, Integer month, Integer day) {

        return repository.findAll().stream()
                .filter(r -> year == null || r.getTimestamp().getYear() == year)
                .filter(r -> month == null || r.getTimestamp().getMonthValue() == month)
                .filter(r -> day == null || r.getTimestamp().getDayOfMonth() == day)
                .collect(Collectors.toList());
    }

    @Override
    public List<MonthlyStatsDTO> getTemperatureAnalytics(int year) {

        List<WeatherRecord> yearData = repository.findAll().stream()
                .filter(r -> r.getTimestamp().getYear() == year)
                .collect(Collectors.toList());
        if (yearData.isEmpty()) {
            throw new WeatherException("No weather data found for year: " + year);
        }
        Map<Integer, List<Double>> grouped =
                yearData.stream()
                        .filter(r -> r.getTemperature() != null)
                        .collect(Collectors.groupingBy(
                                r -> r.getTimestamp().getMonthValue(),
                                Collectors.mapping(
                                        WeatherRecord::getTemperature,
                                        Collectors.toList()
                                )
                        ));

        List<MonthlyStatsDTO> result = new ArrayList<>();

        grouped.forEach((month, temps) -> {

            Collections.sort(temps);

            double median = temps.size() % 2 == 0 ?
                    (temps.get(temps.size()/2) +
                     temps.get(temps.size()/2 - 1)) / 2
                    :
                    temps.get(temps.size()/2);

            // ✅ MANUAL DTO CREATION (NO BUILDER)
            MonthlyStatsDTO dto = new MonthlyStatsDTO();
            dto.setMonthName(java.time.Month.of(month).name());
            dto.setMaxTemp(Collections.max(temps));
            dto.setMinTemp(Collections.min(temps));
            dto.setMedianTemp(median);

            result.add(dto);
        });

        return result;
    }

    private Double parseSafe(String val) {

        if (val == null)
            return null;

        val = val.trim();

        if (val.isEmpty()
                || val.equalsIgnoreCase("NaN")
                || val.equalsIgnoreCase("N/A")
                || val.equalsIgnoreCase("-")
                || val.equalsIgnoreCase("null")) {
            return null;
        }

        try {
            return Double.parseDouble(val);
        } catch (NumberFormatException e) {
            return null;  // skip invalid numbers safely
        }
    }
}